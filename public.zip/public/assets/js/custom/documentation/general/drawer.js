/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
/*!********************************************************!*\
  !*** ../src/js/custom/documentation/general/drawer.js ***!
  \********************************************************/


// Class definition
var KTGeneralDrawerDemos = function() {
    // Private functions
    var _exampleBasic = function() {
    }

    return {
        // Public Functions
        init: function() {
            _exampleBasic();
        }
    };
}();

// On document ready
KTUtil.onDOMContentLoaded(function() {
    KTGeneralDrawerDemos.init();
});

/******/ })()
;
//# sourceMappingURL=drawer.js.map