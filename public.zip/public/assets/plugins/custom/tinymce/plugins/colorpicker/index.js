// Exports the "colorpicker" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/plugins/colorpicker')
//   ES2015:
//     import 'tinymce/plugins/colorpicker'
require('./plugin.js');